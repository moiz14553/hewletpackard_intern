package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class Employees {
    private List<Employee> employeeList;

    // Constructor to initialize the employee list
    public Employees() {
        this.employeeList = new ArrayList<>();
    }

    // Getter for employee list
    public List<Employee> getEmployeeList() {
        return employeeList;
    }

    // Setter for employee list
    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    // Method to add an employee
    public void addEmployee(Employee employee) {
        employeeList.add(employee);
    }
    
    // Method to get an employee by ID
    public Employee getEmployeeById(int id) {
        return employeeList.stream().filter(emp -> emp.getEmployeeId() == id).findFirst().orElse(null);
    }

    // Method to remove an employee
    public void removeEmployee(int id) {
        employeeList.removeIf(emp -> emp.getEmployeeId() == id);
    }
}
