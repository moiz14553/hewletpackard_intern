package com.example.demo;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeManager {
    private List<Employee> employees;

    // Constructor to initialize sample employees
    public EmployeeManager() {
        employees = new ArrayList<>();
        // Adding some sample employees
        employees.add(new Employee(1, "John", "Doe", "john.doe@example.com", "Developer"));
        employees.add(new Employee(2, "Jane", "Doe", "jane.doe@example.com", "Manager"));
        employees.add(new Employee(3, "Jim", "Beam", "jim.beam@example.com", "Designer"));
    }

    // Method to get all employees
    public List<Employee> getAllEmployees() {
        return employees;
    }

    // Method to add a new employee
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Method to get an employee by ID (optional)
    public Employee getEmployeeById(int id) {
        return employees.stream().filter(emp -> emp.getEmployeeId() == id).findFirst().orElse(null);
    }

    // Method to remove an employee (optional)
    public void removeEmployee(int id) {
        employees.removeIf(emp -> emp.getEmployeeId() == id);
    }
}
